#If data is close to zero, unbiased data.  Higher value, more likely biased.
install.packages('SimDesign')
library('SimDesign')

#create data to check
actual_temp <- c(69,69,69,68,75,99)
predicted_temp <- c(61,68.5,68.7,70,72,98)

#check bias; result is very high because I messed with the data
bias(actual_temp,predicted_temp)
