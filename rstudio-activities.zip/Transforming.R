#to create a data frame, enter the following

library("tidyverse")

id <- c(1:10)

name <- c("John Mendes", "Rob Stewart", "Rachel Abrahamson", "Christy Hickman", "Johnson Harper", "Candace Miller", "Carlson Landy", "Pansy Jordan", "Darius Berry", "Claudia Garcia")

job_title <- c("Professional", "Programmer", "Management", "Clerical", "Developer", "Programmer", "Management", "Clerical", "Developer", "Programmer")

employee <- data.frame(id, name, job_title)

#separate employee names once " " AKA space is detected, into two rows consisting of first and last names
separate(employee, name,into=c('first_name','last_name'), sep=' ')

#ERROR!!!join the two previous columns back into a single name seperated by a space
#unite(employee,'name',first_name,last_name,sep=' ')

#convert penguin KG to Grams
penguins %>% 
  mutate(body_mass_kg=body_mass_g/1000)

#storing as conversion function
KG_to_Gram <- penguins %>% 
  mutate(body_mass_kg=body_mass_g/1000)