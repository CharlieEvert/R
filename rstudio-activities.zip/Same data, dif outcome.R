#get the package, enable library, view data
install.packages('Tmisc')
library(Tmisc)
data(quartet)
View(quartet)

#Summary stats
quartet %>% 
  group_by(set) %>% 
  summarize(mean(x),sd(x),mean(y),cor(x,y))

#ERROR INVOLVING (METHOD=?m) plot the data
ggplot(quartet,aes(x,y)) + geom_point() + geom_smooth(method=1m,se=FALSE) + facet_wrap(-)

#ERROR- no package?  get better data viz pckgs
install.packages('datasauRus')
library('datasuaRus')