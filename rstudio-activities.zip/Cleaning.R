install.packages("here")
  library("here")
install.packages("skimr")
  library("skimr")
install.packages("janitor")
  library("janitor")
install.packages("dplyr")
  library("dplyr")
install.packages("palmerpenguins")
  library("palmerpenguins")

#skim_without_charts(penguins) BROKEN CODE!!! NEED FIX!!!
glimpse(penguins)
head(penguins)

#selects every column but species
penguins %>% 
  select(-species)

#changes names of column from island_new to island
penguins %>% 
  rename(island_new=island)

#renames selected column names with all uppercase
rename_with(penguins,toupper)

#renames selected column names with all lowercase
rename_with(penguins,tolower)

#ensures only characters, nums and underscores in names ERROR!!! 
clean_names(penguins)