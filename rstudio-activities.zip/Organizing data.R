library("palmerpenguins")

#sorts data by some column; returns touple sorted by bill length in ascending order
penguins %>% 
  arrange(bill_length_mm)

#save as func
penguins2 <- penguins %>% 
  arrange(bill_length_mm)

#view the func above
View(penguins2)

#sorts data by some column; returns touple sorted by bill length in descending order (minus sign!)
penguins %>% 
  arrange(-bill_length_mm)

#groups penguins by island and [drop any null values from dataset](ERROR IN BRACKETS), summarized by the average bill (penguin snout) length
penguins %>% group_by(island) %>% 
  #drop_na() %>% 
  summarize(mean_bill_length_mm=mean(bill_length_mm))
  
#groups penguins by island and [drop any null values from dataset](ERROR IN BRACKETS), summarized by the maximum bill (penguin snout) length
penguins %>% group_by(island) %>% 
  #drop_na() %>% 
  summarize(max_bill_length_mm=max(bill_length_mm))

#The above, but both mean and max are returned
penguins %>% 
  group_by(species,island) %>% 
  #drop_na() %>% 
  summarize(max_bl=max(bill_length_mm),mean_bl=mean(bill_length_mm))

#Filters penguins and only returns those that are of the Adelie species
penguins %>% 
    filter(species=="Adelie")