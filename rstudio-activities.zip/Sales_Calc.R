# calculating dis ish
q1_sales <- 69
q2_sales <- -96
midyear_sales <- q1_sales + q2_sales
yearend_sales <- midyear_sales * 2
if (yearend_sales > 0) {
  print("Year End Sales are positive!")
} else {
  print("Your sales suck this year, pick it up!")
}

# CMD+SHIFT+M gets Pipe %>% 